import { PercentagePipe } from './percentage.pipe';

describe('PercentagePipe', () => {
  it('create an instance', () => {
    const pipe = new PercentagePipe();
    expect(pipe).toBeTruthy();
  });
});
