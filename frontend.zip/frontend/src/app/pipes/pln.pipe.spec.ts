import { PlnPipe } from './pln.pipe';

describe('PlnPipe', () => {
  it('create an instance', () => {
    const pipe = new PlnPipe();
    expect(pipe).toBeTruthy();
  });
});
