import { HightLightDirective } from './hight-light.directive';

describe('HightLightDirective', () => {
  it('should create an instance', () => {
    const directive = new HightLightDirective();
    expect(directive).toBeTruthy();
  });
});
