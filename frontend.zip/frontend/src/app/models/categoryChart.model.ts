export interface CategoryChart {
    name: string;
    color: string;
    sum: number;
}