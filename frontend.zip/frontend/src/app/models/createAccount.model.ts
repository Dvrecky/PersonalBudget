export interface CreateAccount {
    name: string,
    balance: number
}