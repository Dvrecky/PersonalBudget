export interface CategorySummary{
    name: string,
    percentage: number,
    amount: number,
    iconPath: string,
    color: string,
}