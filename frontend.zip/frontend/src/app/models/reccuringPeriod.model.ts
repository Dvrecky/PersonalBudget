export enum ReccuringPeriod {
    None = "none",
    Daily = "daily",
    Weekly = "weekly",
    monthly = "monthly",
    Yearly = "yearly",
}
