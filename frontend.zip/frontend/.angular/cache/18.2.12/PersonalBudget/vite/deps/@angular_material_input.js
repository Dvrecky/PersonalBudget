import {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
} from "./chunk-2XOACIP3.js";
import "./chunk-LXWCL6ZN.js";
import "./chunk-NHXS2ZHO.js";
import "./chunk-DWUJAFI2.js";
import "./chunk-2KFG5D5N.js";
import "./chunk-N3GF34XS.js";
import "./chunk-V4VBF4VV.js";
import "./chunk-DTRZVJQ6.js";
import "./chunk-KIHTX5Y7.js";
import "./chunk-4N4GOYJH.js";
import "./chunk-5OPE3T2R.js";
import "./chunk-FHTVLBLO.js";
import "./chunk-WDMUDEB6.js";
export {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
};
//# sourceMappingURL=@angular_material_input.js.map
